# Encoded round1 independent review

**Decision: required fixes remain only in the already identified recording-UI cleanup and closed-eye mask guard. No additional eye timing, geometry, flash-transition or particle-timing fix was found.**

Candidate reviewed:

`/workspace/scratch/04183dcc69e7/anime-reassembly-v9/out/round1/Seaside_Reassembly.mp4`

This review decoded the actual MP4, generated same-frame reference/v8/candidate contacts, and inspected the resulting images. It did not infer success solely from source code or timing JSON.

## Verified

- 298 video frames,30fps,1440×900; duration9.933333s.
- Source welcome layout, ring, title and particle-field/reassembly positions match at the inspected source frames0,30,32,33,36,42,60,76,84,96,108,120.
- White flash peaks at source frame124 and candidate frame124: **0-frame offset**.
- The frame125→126 reveal does not introduce a geometry jump. Reference mean luma180.92→125.03; candidate179.59→124.40. Subsequent126–131 values track the same flash-decay shape. Different character material coloration introduces small expected luminance changes, not a second transition.
- Hair outlines, upper-lash silhouettes, eyelid shape, eye aperture and head positions agree in the encoded same-frame views throughout200–297.
- Left iris is fully occluded in233/234; the first actual colored slit appears in235 in both source and recreation.235–237 preserve the source's narrow opening;238/240/243 match the source's successive aperture stages. There is no separately invented fade opening.
- Detailed235/240 crops show the new blue-violet iris stays above the true lower-lid boundary. No broad blue spill onto the pink lower eyelid was found in these inspected encoded frames.
- The source right-eye narrow wedge remains visible before the left eye, matching the supplied motion. Do not impose a shared new start gate on both eyes.
- Decoded monoPCM comparison against the original reference gives **0 samples offset at16kHz**, zero-lag correlation0.999075. Root is separately replacing the old transcoded audio with original AAC packets for final; the current candidate has no time displacement.
- No decoded-frame corruption, new camera move, reversal, repeated blink or unrelated frame offset was found.

## Required fixes already coordinated with root

1. The external auto-next countdown begins faintly at **frame259**, not267. In a native bottom-left ROI excluding the internal corner: frame258 maximum luma50;259max70;260max116 with99pixels>100;261max163;262max205. Cleanup should begin at259 so the faint entry is not left behind.
2. The current broad cleanup damages the internal bottom-left L corner and the small footer text. Restore both the corner and the native footer aroundx43–106,y452–459 while removing only the external countdown. `bottom_left_cleaning_review.jpg` shows this precisely.
3. Root/motion agent already identified and are correcting the tiny false-blue response during the photographic flash near127, with the right-eye visibility guard based on the actually closed source frames. This review does not duplicate that finding.

After these known corrections and final original-audio mux, rerender and perform focused verification of127,259–267,284/297. No further broad rework is justified by the inspected evidence.

## Evidence

- `intro_comparison.jpg`, `eyes_comparison.jpg`
- `intro_three_columns.jpg`, `eyes_three_columns.jpg`
- `left_first_open_detailed.jpg`, `right_first_open_detailed.jpg`
- `bottom_left_cleaning_review.jpg`
- `review_metrics.json`
- `independent_sync_and_geometry.json`

The high-pass nearest-frame diagnostic sometimes selects an adjacent member of a duplicated source-frame run by a negligible compression difference; that is not evidence of a time offset. The visually changing flash and eye stages align with their exact reference frame numbers. Audio evaluation here used decoded signal analysis, not an auditory listening claim.
