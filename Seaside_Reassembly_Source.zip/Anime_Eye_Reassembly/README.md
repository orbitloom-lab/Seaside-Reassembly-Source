# 黑长直动漫人物 · 参考逐帧动作复刻（v9）

成片：1440×900，30fps，298帧，有效画面时长9.933秒。

本次以用户提供的参考动画本身为动作底版。原片的粒子、线稿、闪白、眼睑、
睫毛、视线上抬、头部和发丝的运动均对应原始帧；角色外观替换为蓝紫金色虹膜、
偏冷黑发反光与新生成角色的肤色材质。没有使用开眼与闭眼图片之间的透明度渐变。

## 与前一版的主要区别

- 欢迎头像、圆环、标题、粒子路径、线稿汇聚和闪白改为原参考实际画面。
- 调整人物的朝向、近景比例和遮挡关系，使用参考实际几何和连续动作。
- 根据可见眼球边界替换虹膜，眼皮、黑色瞳孔、白色反光和睫毛保持真实遮挡。
- 右眼在参考约7秒时出现暗细缝，左眼235帧首次出现虹膜；保留两眼实际差异。
- 保留原参考音乐的AAC数据包，起始时间为0，不变速、不平移、不重新编码。
- 只输出参考内部的有效动画，去除手机黑边、桌面、触控按钮、自动播放倒计时和后续编辑器。

## 构建

需要Python 3、FFmpeg、Node.js。安装Python依赖：

```bash
python3 -m pip install -r scripts/motion_requirements.txt
python3 scripts/build_reference_video.py
python3 scripts/encode_frames.py
```

首次构建会从原参考生成可再生的光流缓存，然后写入298张最终帧。
输出视频位于 `out/Seaside_Reassembly.mp4`。

Remotion交互预览：

```bash
npm ci
npm run studio
```

预览使用与导出相同的最终帧和原音轨。执行Python构建后再打开预览。

## 文件

- `public/assets/reference/source.mp4`：用户提供的原始参考录屏。
- `public/assets/reference-audio.m4a`：从参考无重编码提取的原音轨。
- `public/assets/character/reference_aligned_open.png` 与 `reference_aligned_closed.png`：内置生图生成的角色材质关键帧。
- `scripts/reference_motion.py`：逐帧角色材质映射、真实遮挡、视线运动、录屏提示清理。
- `scripts/aperture_boundaries.json`：人工复核的眼睑内缘、虹膜区域以及跟踪数据。
- `scripts/reference_intro.py`：保留原始片头，只替换欢迎头像。
- `scripts/build_motion_maps.py`：从参考生成运动映射，可重新生成缓存。
- `reference-crop.json`：参考范围和阶段时间。
- `ITERATION_LOG.md` 与 `MOTION_REVIEW.md`：各轮渲染、对比和修正记录。
- `CHARACTER_REPLACEMENT.md`：角色替换方法与生成素材指令。
- `mask-verification.json`：172帧遮挡检查及皮肤/虹膜样点结果。

交付源包不包含可重新生成的缓存、逐帧PNG和node_modules；包含原始参考、角色素材、
音轨、脚本和边界标注，能够重新构建。原始录屏只作为本次用户授权编辑的输入。
