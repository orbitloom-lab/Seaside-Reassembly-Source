#!/usr/bin/env python3
"""Encode the source-locked 298-frame animation with the reference audio."""
from pathlib import Path
import argparse
import subprocess
import json

ROOT = Path(__file__).resolve().parents[1]

def encode(frames, output, quality=16):
    frames, output = Path(frames), Path(output)
    if len(list(frames.glob('frame-*.png'))) != 298:
        raise ValueError('All 298 source-aligned frames must exist before export.')
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [
        'ffmpeg', '-hide_banner', '-loglevel', 'warning', '-y',
        '-framerate', '30', '-i', str(frames/'frame-%04d.png'),
        '-i', str(ROOT/'public/assets/reference-audio.m4a'),
        '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'libx264',
        '-preset', 'slow', '-crf', str(quality), '-pix_fmt', 'yuv420p',
        '-c:a', 'copy', '-t', str(298/30), '-movflags', '+faststart',
        '-metadata', 'title=黑长直动漫人物 · 参考动作逐帧复刻',
        str(output)
    ]
    subprocess.run(command, check=True)
    print(json.dumps({'output': str(output), 'bytes': output.stat().st_size,
                      'frames':298,'fps':30,'duration':298/30},ensure_ascii=False))

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--frames',type=Path,default=ROOT/'public/assets/final')
    p.add_argument('--output',type=Path,default=ROOT/'out/Seaside_Reassembly.mp4')
    p.add_argument('--quality',type=int,default=16)
    a=p.parse_args(); encode(a.frames,a.output,a.quality)
