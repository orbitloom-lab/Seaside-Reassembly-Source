import sys,json,time
from pathlib import Path
try:
 import cv2
except ImportError:
 for parent in Path(__file__).resolve().parents:
  extra=parent/'motion_work/python_packages'
  if extra.is_dir():sys.path.insert(0,str(extra));break
import cv2,numpy as np
def build_fields(source_path,destination):
 D=Path(destination); D.mkdir(exist_ok=True,parents=True)
 CROP=(177,20,758,473);START=126;END=297;CK=180;OK=284
 cap=cv2.VideoCapture(str(source_path))
 frames=[]
 for f in range(END+1):
  ok,im=cap.read()
  if not ok:raise RuntimeError('missing frame')
  x,y,w,h=CROP;frames.append(im[y:y+h,x:x+w])
 # Blur destroys scan-line noise, but preserves eyelid and hair geometry.
 small=[cv2.resize(cv2.GaussianBlur(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(0,0),.65),(379,237),interpolation=cv2.INTER_AREA) for im in frames]
 dis=cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
 dis.setFinestScale(0);dis.setGradientDescentIterations(30);dis.setPatchSize(8);dis.setPatchStride(3)
 arrays={}
 for tag,anchor in [('closed',CK),('open',OK)]:
  maps=[]
  for f in range(START,END+1):
   flow=dis.calc(small[f],small[anchor],None)
   flow[...,0]*=758/379;flow[...,1]*=473/237
   maps.append(flow.astype(np.float16))
   if f%30==0:print(tag,f,flush=True)
  arrays[tag]=np.stack(maps)
  np.savez_compressed(D/f'current_to_{tag}_{anchor}.npz',flow=arrays[tag],frames=np.arange(START,END+1),crop=np.array(CROP),grid=np.array([379,237]),flow_units='full_crop_pixels')
 cv2.imwrite(str(D/'source_closed_180.png'),frames[CK]);cv2.imwrite(str(D/'source_open_284.png'),frames[OK])
 # Store source visual frames as lossy-free input for comparator/prototyping only.
 np.savez_compressed(D/'source_frames_126_297.npz',frames=np.stack(frames[START:END+1]),indices=np.arange(START,END+1))
 meta=dict(crop=dict(x=177,y=20,width=758,height=473),fps=30,start_frame=START,end_frame=END,closed_anchor=CK,open_anchor=OK,field_grid=[379,237],flow_units='full_crop_pixels',mapping='For current output pixel (x,y), sample closed/open target plate aligned to respective source anchor at (x+flow_x,y+flow_y). Upsample flow first, do NOT multiply magnitude during upsampling: already expressed in full crop pixels.',method='OpenCV DIS medium, grayscale blur sigma0.65, half grid, finestScale0, patch8/stride3, gradient descent30',limitations='No single flow can resolve occlusion. Closed-source mapping used for skin/lashes; open-source mapping for visible eye aperture. Source recording overlays are not part of target texture and must not be transferred.')
 (D/'metadata.json').write_text(json.dumps(meta,indent=2))
 print('done',flush=True)

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('source_path',nargs='?',default=str(Path(__file__).parent.parent/'reference_v8/ScreenRecording_10-29-2026 16-17-08_1.mp4'));ap.add_argument('--destination',default=str(Path(__file__).parent/'motion_fields'));a=ap.parse_args();build_fields(a.source_path,a.destination)
