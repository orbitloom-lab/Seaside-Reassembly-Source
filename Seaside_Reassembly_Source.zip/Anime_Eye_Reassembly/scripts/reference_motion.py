"""Reference geometry as authoritative motion; replace character appearance.
No temporal crossfade or eyelid interpolation. Source eyelash/skin silhouettes
physically occlude separately mapped generated iris material on every frame.
"""
import sys,json,argparse
from pathlib import Path
try:
 import cv2
except ImportError:
 for parent in Path(__file__).resolve().parents:
  extra=parent/'motion_work/python_packages'
  if extra.is_dir():sys.path.insert(0,str(extra));break
import cv2,numpy as np
from scipy.interpolate import PchipInterpolator
D=Path(__file__).parent;W,H=758,473;START=126
OPEN=D.parent/'public/assets/character/reference_aligned_open.png'
CLOSED=D.parent/'public/assets/character/reference_aligned_closed.png'
YY,XX=np.mgrid[:H,:W].astype(np.float32)

def smooth(a,b,x):
 q=np.clip((x-a)/(b-a),0,1);return q*q*(3-2*q)
def warp(im,fl):return cv2.remap(im,XX+fl[...,0],YY+fl[...,1],cv2.INTER_CUBIC,borderMode=cv2.BORDER_REFLECT101)
def gray(im):return cv2.GaussianBlur(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(0,0),.7)
def dense(a,b):
 dis=cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM);dis.setFinestScale(0);dis.setGradientDescentIterations(30);dis.setPatchSize(8);dis.setPatchStride(3)
 aa=cv2.resize(gray(a),(379,237),interpolation=cv2.INTER_AREA);bb=cv2.resize(gray(b),(379,237),interpolation=cv2.INTER_AREA)
 fl=dis.calc(aa,bb,None);fl[...,0]*=2;fl[...,1]*=H/237
 return cv2.resize(fl,(W,H),interpolation=cv2.INTER_LINEAR)
def lab(im):return cv2.cvtColor(im.astype(np.float32)/255,cv2.COLOR_BGR2LAB)
def rgb(labim):return np.clip(cv2.cvtColor(labim.astype(np.float32),cv2.COLOR_LAB2BGR)*255,0,255)

class ReferenceRetargeter:
 def __init__(self,source_path=None,open_path=None,closed_path=None,cache_directory=None,boundaries_path=None):
  cache=Path(cache_directory) if cache_directory else D.parent/'.cache/motion'
  if not (cache/'source_frames_126_297.npz').exists():
   from build_motion_maps import build_fields
   if source_path is None:source_path=D.parent/'public/assets/reference/source.mp4'
   build_fields(source_path,cache)
  self.source=np.load(cache/'source_frames_126_297.npz')['frames']
  self.cf=np.load(cache/'current_to_closed_180.npz')['flow']
  self.of=np.load(cache/'current_to_open_284.npz')['flow']
  self.sclose=self.source[180-126];self.sopen=self.source[284-126]
  tc=cv2.resize(cv2.imread(str(closed_path or CLOSED)),(W,H),interpolation=cv2.INTER_AREA)
  to=cv2.resize(cv2.imread(str(open_path or OPEN)),(W,H),interpolation=cv2.INTER_AREA)
  # Appearance fields only: source geometry never comes from this registration.
  fl=dense(self.sclose,tc)
  fl=cv2.GaussianBlur(np.clip(fl,-45,45),(0,0),16)
  target=warp(tc,fl)
  source_lab=lab(self.sclose);target_lab=lab(target)
  sample=np.zeros((H,W),bool);sample[260:400,400:540]=True;sample[250:350,685:730]=True
  self.tone=np.median((target_lab-source_lab)[sample],axis=0)
  self.tone=np.clip(self.tone,[-4,-7,-7],[4,7,7]);self.tone[0]*=.5
  self.eyes=[dict(name='left',box=(110,220,280,320),poly=[(118,238),(132,213),(164,197),(200,192),(237,199),(259,217),(263,247),(254,275),(236,297),(211,312),(187,319),(159,310),(139,299),(125,281)]),dict(name='right',box=(570,70,690,175),poly=[(566,126),(570,101),(586,79),(614,64),(644,62),(661,80),(665,104),(656,130),(641,151),(621,166),(603,173),(582,162),(571,145)])]
  anchor_flow=dense(self.sopen,to)
  hsv=cv2.cvtColor(self.sopen,cv2.COLOR_BGR2HSV);hh,ss,vv=cv2.split(hsv)
  rr=(((hh>168)|(hh<10))&(ss>90)&(vv>50))
  boundary_doc=json.loads(Path(boundaries_path or D/'aperture_boundaries.json').read_text())
  for e in self.eyes:e['poly']=boundary_doc['iris_polygons'][e['name']]
  self.lidtracks=boundary_doc['lid_tracks']
  self.manual_lower={name:{int(f):points for f,points in dd.items()} for name,dd in boundary_doc['manual_lower'].items()}
  self.material=[];self.masks=[]
  for e in self.eyes:
   x0,y0,x1,y1=e['box'];selection=np.zeros((H,W),bool);selection[y0:y1,x0:x1]=True;selection&=rr
   ys,xs=np.nonzero(selection);a=np.stack([xs,ys],axis=1).astype(np.float32);b=a+anchor_flow[ys,xs]
   M,inliers=cv2.estimateAffinePartial2D(a,b,method=cv2.RANSAC,ransacReprojThreshold=3,maxIters=5000)
   mx=M[0,0]*XX+M[0,1]*YY+M[0,2];my=M[1,0]*XX+M[1,1]*YY+M[1,2]
   mat=cv2.remap(to,mx.astype(np.float32),my.astype(np.float32),cv2.INTER_CUBIC,borderMode=cv2.BORDER_REFLECT101)
   disk=np.zeros((H,W),np.float32);cv2.fillPoly(disk,[np.array(e['poly'],np.int32)],1.)
   disk=cv2.GaussianBlur(disk,(0,0),1.)
   hsv=cv2.cvtColor(mat,cv2.COLOR_BGR2HSV);spec=((hsv[:,:,1]<85)&(hsv[:,:,2]>185)&(disk>.1)).astype(np.uint8)*255
   spec=cv2.dilate(spec,np.ones((3,3),np.uint8));mat=cv2.inpaint(mat,spec,4,cv2.INPAINT_TELEA)
   self.material.append(mat.astype(np.float32));self.masks.append(disk)
   e['material_affine']=M.tolist()
  self.aperture=np.zeros((H,W),np.float32)
  for poly in [[(72,280),(92,254),(126,232),(166,211),(210,199),(254,196),(292,201),(329,214),(354,226),(334,251),(310,274),(276,295),(244,312),(210,322),(170,324),(129,316),(96,301)],[(557,163),(563,140),(582,116),(605,92),(633,75),(662,60),(693,54),(721,57),(739,69),(729,100),(710,127),(685,150),(654,169),(621,181),(588,181),(567,174)]]:
   cv2.fillPoly(self.aperture,[np.array(poly,np.int32)],1.)
  self.aperture=cv2.GaussianBlur(cv2.erode(self.aperture,np.ones((3,3),np.uint8)),(0,0),.6)
  self.hair_region=np.zeros((H,W),np.float32)
  cv2.fillPoly(self.hair_region,[np.array([(340,0),(645,0),(580,150),(520,242),(425,285),(340,255)],np.int32)],1.)
  self.hair_region=cv2.GaussianBlur(self.hair_region,(0,0),10)
  self.ui_regions=np.zeros((H,W),np.float32)
  self.ui_regions[:70,:225]=1;self.ui_regions[400:444,260:540]=1
  self.ui_regions[:24,:30]=1;self.ui_regions[:24,-30:]=1;self.ui_regions[-30:,:30]=1;self.ui_regions[-34:,-120:]=1
  self._debug={}
 def lid_limit(self,name,frame):
  keys=sorted(self.manual_lower[name]);arr=[];xs=np.arange(W)
  for k in keys:
   p=np.array(self.manual_lower[name][k],np.float32);arr.append(PchipInterpolator(p[:,0],p[:,1],extrapolate=True)(xs))
  lo=np.asarray(PchipInterpolator(keys,np.stack(arr),axis=0)(np.clip(frame,keys[0],keys[-1]))) if len(keys)>1 else arr[0]
  # Edge extrapolation is never allowed to introduce a second eye elsewhere.
  p0=np.array(self.manual_lower[name][keys[0]],np.float32);pn=np.array(self.manual_lower[name][keys[-1]],np.float32)
  xmin=min(p0[:,0].min(),pn[:,0].min());xmax=max(p0[:,0].max(),pn[:,0].max())
  if frame>keys[-1] or frame<keys[0]:
   k=keys[-1] if frame>keys[-1] else keys[0]
   if str(frame) in self.lidtracks[name] and str(k) in self.lidtracks[name]:
    p=np.array(self.lidtracks[name][str(frame)]);b=np.array(self.lidtracks[name][str(k)]);lo+=float(np.median(p[:,1]-b[:,1]))
  return lo,(xs>=xmin)&(xs<=xmax)
 def render(self,frame,debug=False):
  i=int(frame)-START;src=self.source[i].copy()
  if frame>=259:
   # The recorder's auto-next overlay starts its faint fade at259. Use its
   # fully visible glyph shape as a mask even during those first faint frames.
   # This removes only recording UI and preserves the actual effect's HUD.
   template=self.source[265-START]
   hsv=cv2.cvtColor(template,cv2.COLOR_BGR2HSV);m=np.zeros((H,W),np.uint8)
   m[438:,:77]=((hsv[438:,:77,1]<80)&(hsv[438:,:77,2]>140)).astype(np.uint8)*255
   m=cv2.dilate(m,np.ones((5,5),np.uint8))
   limit=np.zeros_like(m);limit[436:,:80]=255;m=np.minimum(m,limit)
   src=cv2.inpaint(src,m,4,cv2.INPAINT_TELEA)
   corner=(((np.abs(XX-10)<=2)&(YY>=442)&(YY<=464))|
           ((np.abs(YY-462)<=2)&(XX>=8)&(XX<=31)))
   clean=self.source[258-START]
   src[corner]=clean[corner]
   # Restore only original footer glyph strokes where cleanup touched them.
   # No rectangle of the older face is pasted over the moving character.
   footer=(XX>=43)&(XX<106)&(YY>=452)&(YY<460)&(m>0)
   cg=cv2.cvtColor(clean,cv2.COLOR_BGR2GRAY).astype(np.float32)
   cb=cv2.morphologyEx(cg,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
   residue=np.clip(cg-cb,0,255)
   coverage=np.clip(residue/np.maximum(255-cb,1),0,1)*footer
   src=np.clip(src*(1-coverage[...,None])+255*coverage[...,None],0,255).astype(np.uint8)
  cf=cv2.resize(self.cf[i].astype(np.float32),(W,H),interpolation=cv2.INTER_LINEAR)
  of=cv2.resize(self.of[i].astype(np.float32),(W,H),interpolation=cv2.INTER_LINEAR)
  source_lab=lab(src)
  strength=smooth(3,25,source_lab[:,:,0])
  field=self.tone[None,None,:]*strength[...,None]
  # Preserve flash intensity and all geometric luminance detail.
  flash={126:.344,127:.521,128:.764,129:.904,130:.992}.get(frame,1.)
  result=rgb(source_lab+field*flash)
  hair=warp(self.hair_region,cv2.GaussianBlur(cf,(0,0),6))
  B,G,R=cv2.split(src.astype(np.float32))
  hair*=smooth(1.05,1.4,R/(B+1))*smooth(1.2,1.8,R/(G+1))*(1-smooth(120,170,R))
  cool=src.astype(np.float32).copy();cool[:,:,0]=np.maximum(B,R*.9);cool[:,:,2]=R*.67+B*.33
  result=result*(1-hair[...,None])+cool*hair[...,None]
  hsv=cv2.cvtColor(src,cv2.COLOR_BGR2HSV).astype(np.float32);h,s,v=hsv[:,:,0],hsv[:,:,1],hsv[:,:,2]
  # Source iris RGB provides a precise current occlusion silhouette. Dark
  # eyelashes and white highlights remain original opaque source pixels.
  red=(smooth(162,174,h)+1-smooth(5,14,h)).clip(0,1)*smooth(55,105,s)*smooth(20,60,v)
  aperture=np.clip(warp(self.aperture,of),0,1)
  iris_total=np.zeros((H,W),np.float32);stats=[]
  for e,mat,disk in zip(self.eyes,self.material,self.masks):
   lower,xlimits=self.lid_limit(e['name'],frame)
   ink_run=cv2.boxFilter((v<38).astype(np.float32),-1,(1,5),normalize=True)>.98
   eligible=ink_run&(YY<lower[None,:]-3)&(YY>lower[None,:]-170)
   top=np.max(np.where(eligible,YY,-1000),axis=0)+3
   manual_ap=smooth(top[None,:]-.5,top[None,:]+.5,YY)*(1-smooth(lower[None,:]-1.5,lower[None,:]-.5,YY))*xlimits[None,:]
   # Robust visible-iris correspondence estimates translation; the texture
   # itself never compresses with eyelid height.
   search=(warp(disk,of)>.3)&(red>.8)&(manual_ap>.8)
   pts=of[search]
   dx,dy=(np.median(pts,axis=0) if len(pts)>8 else np.array([0.,0.]))
   dx=float(np.clip(dx,-45,30));dy=float(np.clip(dy,-85,35))
   mx=XX+dx;my=YY+dy
   mapped=cv2.remap(mat,mx,my,cv2.INTER_CUBIC,borderMode=cv2.BORDER_REFLECT101)
   m=cv2.remap(disk,mx,my,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
   m=m*red*manual_ap
   if (e['name']=='left' and frame<235) or (e['name']=='right' and frame<208):m.fill(0)
   # Fill generated material at source-visible red pixels. Keep source
   # brightness modulation so overlying shadows stay opaque and immediate.
   # Exact source value retains the visibility/contrast timing of the source.
   mapped*=np.clip(v/np.maximum(np.max(mapped,axis=2),1),0,2)[...,None]
   result=result*(1-m[...,None])+mapped*m[...,None]
   iris_total=np.maximum(iris_total,m)
   stats.append(dict(eye=e['name'],dx=dx,dy=dy,visible_pixels=float(m.sum())))
  ui=(self.ui_regions*((s<65)&(v>160))).astype(np.float32)
  ui=cv2.GaussianBlur(cv2.dilate(ui,np.ones((3,3),np.uint8)),(0,0),.5)
  result=result*(1-ui[...,None])+src*ui[...,None]
  result=np.clip(result,0,255).astype(np.uint8)
  if debug:self._debug=dict(source=src,iris_mask=iris_total,stats=stats)
  return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--all',action='store_true');ap.add_argument('--out',default=str(D/'prototype_round5'));a=ap.parse_args();out=Path(a.out);out.mkdir(exist_ok=True,parents=True)
 rig=ReferenceRetargeter();keys=range(126,298) if a.all else [130,180,200,210,211,222,234,235,236,238,240,243,246,250,260,276,284,297];report=[]
 for n in keys:
  im=rig.render(n,True);cv2.imwrite(str(out/f'frame_{n:03}.png'),im)
  if n in [130,180,200,210,211,222,234,235,236,238,240,243,246,250,260,276,284,297]:
   db=rig._debug;cv2.imwrite(str(out/f'iris_mask_{n:03}.png'),np.rint(db['iris_mask']*255).astype(np.uint8));cv2.imwrite(str(out/f'compare_{n:03}.jpg'),np.concatenate([db['source'],im],axis=1))
  report.append(dict(frame=n,eyes=rig._debug['stats']))
 (out/'metrics.json').write_text(json.dumps(report,indent=2));print(out)
if __name__=='__main__':main()
