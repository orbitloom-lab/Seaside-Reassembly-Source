#!/usr/bin/env python3
"""Retarget the supplied reference introduction, preserving its actual pixels.

Inputs and return values are uint8 RGB arrays in final 1440 x 900 coordinates.
The original screen recording is read only. Only the interior artwork rectangle
is used; the physical monitor, wallpaper, phone margins, and AssistiveTouch are
excluded. Production exact mode preserves source UI and particles through
frame125, for the character retargeter that preserves source geometry.

Example:
  renderer = ReferenceIntro(reference_path, closed_rgb, open_rgb)
  output_rgb = renderer.render(frame_number, living_face_rgb)

In exact mode this renderer owns frames0..125. From126 onward it passes the
motion renderer's RGB frame through without adding flash, fade, or HUD.
The earlier contour reconstruction remains an explicit diagnostic option
(exact_template=False); production never builds or executes that path.
No temporal blending is used for the eyes: this is only the intro compositor.
"""
from pathlib import Path
import argparse
import json
import sys

try:
    import cv2
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'motion_work/python_packages'))
    import cv2
import numpy as np

WIDTH, HEIGHT = 1440, 900
CROP = (177, 20, 758, 473)
BACKGROUND_RGB = np.array([11, 7, 16], dtype=np.float32)

# Empirical fit to reference frames (edge image + face image + RGB flash).
# Frame 123/124 is the actual high flash, rather than a generic long fade.
FLASH = {
    120: (1.0000, 0.0000, [0, 0, 0]),
    121: (1.1123, 0.0000, [0, 0, 0]),
    122: (1.1207, 0.0047, [25.602, 25.177, 24.486]),
    123: (0.2295, 0.0106, [194.808, 184.832, 192.466]),
    124: (0.2145, 0.0207, [196.054, 185.953, 193.742]),
    125: (0.2213, 0.0630, [178.725, 169.920, 176.797]),
    126: (0.1412, 0.3439, [104.734, 99.609, 104.690]),
    127: (0.0736, 0.5212, [68.341, 64.344, 68.445]),
    128: (0.0000, 0.7638, [29.609, 27.174, 29.615]),
    129: (0.0000, 0.9043, [8.632, 7.102, 8.357]),
    130: (0.0000, 0.9915, [0.492, 0.461, 0.480]),
    131: (0.0000, 0.9946, [0.437, 0.302, 0.392]),
}


def smooth01(value):
    value = np.clip(value, 0.0, 1.0)
    return value * value * (3.0 - 2.0 * value)


def _rgb(path):
    im = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if im is None:
        raise FileNotFoundError(path)
    return cv2.cvtColor(im, cv2.COLOR_BGR2RGB)


class ReferenceIntro:
    def __init__(self, reference_path, closed_rgb, open_rgb,
                 avatar_crop=None, edge_thresholds=(65, 155),
                 exact_template=True):
        self.exact_template = bool(exact_template)
        self.closed = self._size(closed_rgb)
        self.open = self._size(open_rgb)
        self.reference_path = str(reference_path)
        cap = cv2.VideoCapture(self.reference_path)
        self.frames = []
        x, y, w, h = CROP
        while len(self.frames) < 298:
            ok, bgr = cap.read()
            if not ok:
                break
            self.frames.append(cv2.cvtColor(bgr[y:y+h, x:x+w], cv2.COLOR_BGR2RGB))
        cap.release()
        if len(self.frames) < 135:
            raise ValueError('The reference must include at least 135 frames at 30 fps.')

        # The source avatar is square, with its source border left untouched.
        # Only its interior (global source coordinates 480,170..632,322) changes.
        if avatar_crop is None:
            side = min(HEIGHT, int(WIDTH * 0.60))
            avatar_crop = (int(WIDTH * 0.43 - side / 2), 0, side, side)
        ax, ay, aw, ah = [int(v) for v in avatar_crop]
        ax = max(0, min(WIDTH-aw, ax)); ay = max(0, min(HEIGHT-ah, ay))
        self.avatar = cv2.resize(self.open[ay:ay+ah, ax:ax+aw], (152, 152),
                                 interpolation=cv2.INTER_AREA)
        self.avatar_rect_native = (303, 150, 152, 152)

        if self.exact_template:
            # The production character retargeter now preserves reference
            # geometry. Its outlines, fragments, timing, and flash can therefore
            # be copied directly, rather than reconstructed approximately.
            self.reference_metadata = {
                'mode': 'exact_reference_geometry',
                'crop_xywh': list(CROP), 'frame_rate': 30,
                'complete_welcome_last_frame': 32,
                'avatar_replaced_frames': [0,32],
                'avatar_rect_in_crop': list(self.avatar_rect_native),
                'source_pixel_exact_frames': [33,125],
                'flash_peak_frames': [123,124],
                'living_retarget_passthrough_first_frame': 126,
                'note': 'From126 the motion renderer owns source flash, geometry, HUD and the new character. This compositor applies no extra fade or HUD overlay.'
            }
            return

        # Keep exact source corner brackets, instruction text and background.
        self.base_native = self.frames[0].copy()
        self.base_native[65:455, 190:570] = BACKGROUND_RGB.astype(np.uint8)
        self.base = self._size(self.base_native)
        self.xx = np.arange(WIDTH, dtype=np.float32)[None, :] / (WIDTH-1)

        # Use one-pixel traced contour segments, not radial dots. All target
        # geometry is traced from the exact incoming closed frame.
        clean = cv2.bilateralFilter(self.closed, 7, 28, 5)
        gray = cv2.cvtColor(clean, cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(cv2.GaussianBlur(gray, (0, 0), .75),
                          edge_thresholds[0], edge_thresholds[1], L2gradient=True)
        edges[:3] = 0; edges[-3:] = 0; edges[:, :3] = 0; edges[:, -3:] = 0
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        rng = np.random.default_rng(293701)
        self.segments = []
        self.full_edges = np.zeros((HEIGHT, WIDTH, 3), np.uint8)
        self.full_edges[:] = BACKGROUND_RGB.astype(np.uint8)
        for contour in contours:
            pts = contour[:, 0, :]
            if len(pts) < 13:
                continue
            cv2.polylines(self.full_edges, [pts], False, (140, 139, 149), 1, cv2.LINE_AA)
            index = 0
            while index < len(pts)-1:
                length = int(rng.integers(7, 16))
                segment = pts[index:min(index+length+1, len(pts))].astype(np.float32)
                index += length
                if len(segment) < 2:
                    continue
                center = segment.mean(axis=0)
                # Measured from source settled contour columns; leftmost first.
                settled_frame = 76.0 + 44.0 * center[0] / WIDTH
                self.segments.append({
                    'points': segment, 'center': center,
                    'settled': settled_frame,
                    'angle': float(rng.uniform(-2.6, 2.6)),
                    'offset': np.array([rng.uniform(20, 115), rng.uniform(-52, 52)], np.float32),
                    'shade': tuple(int(v) for v in np.clip(np.array([140,139,149]) * rng.uniform(.85,1.06),0,255)),
                })
        # The original photograph-free UI is composited only in edge-safe ROIs.
        self.static_ui_mask_native = np.zeros((h, w), np.uint8)
        for x0,y0,x1,y1 in [(7,5,36,34),(718,5,751,36),(7,430,36,467),
                            (718,430,751,467),(27,404,190,452),(662,438,730,456)]:
            self.static_ui_mask_native[y0:y1,x0:x1] = 255

        # Match reference line exposure after the new topology is traced. This
        # avoids the much brighter, denser line plate seen in first comparison.
        ref_edge_gray = cv2.cvtColor(self.source_frame(120),cv2.COLOR_RGB2GRAY).astype(float)
        target_edge_gray = cv2.cvtColor(self.full_edges,cv2.COLOR_RGB2GRAY).astype(float)
        base_gray = float(cv2.cvtColor(np.uint8(BACKGROUND_RGB)[None,None,:],cv2.COLOR_RGB2GRAY)[0,0])
        self.edge_gain = float(np.clip((ref_edge_gray.mean()-base_gray)/(target_edge_gray.mean()-base_gray),.68,1.12))
        self.full_edges = np.uint8(np.clip(BACKGROUND_RGB+(self.full_edges.astype(float)-BACKGROUND_RGB)*self.edge_gain,0,255))
        for segment in self.segments:
            segment['shade'] = tuple(int(v) for v in BACKGROUND_RGB+(np.array(segment['shade'])-BACKGROUND_RGB)*self.edge_gain)

        self.reference_metadata = {
            'crop_xywh': list(CROP), 'frame_rate': 30,
            'complete_welcome_last_frame': 32, 'shards_first_frame': 33,
            'fine_particles_first_frame': 40,
            'assembly_settle_formula': '76 + 44 * normalized_x',
            'flash_peak_frames': [123,124], 'fully_colored_frame': 130,
            'segments': len(self.segments), 'edge_gain': self.edge_gain,
            'edge_thresholds': list(edge_thresholds),
            'preserved_source_pixel_ranges': [[0,32],[33,68]],
            'character_avatar_replaced_range': [0,32],
            'note': 'The monochrome abstract source shards from frame33 onward preserve original motion, not the old recognizable avatar.',
        }

    @staticmethod
    def _size(rgb):
        if rgb.shape[:2] == (HEIGHT, WIDTH):
            return np.asarray(rgb, dtype=np.uint8).copy()
        return cv2.resize(np.asarray(rgb,dtype=np.uint8), (WIDTH,HEIGHT), interpolation=cv2.INTER_CUBIC)

    def source_frame(self, frame):
        return self._size(self.frames[min(max(int(frame),0),len(self.frames)-1)])

    def _settling_contours(self, frame):
        out = self.base.copy()
        if frame >= 120:
            # Keep precise end geometry; eliminate no-pixel leftovers from cuts.
            m = np.max(self.full_edges.astype(np.int16)-BACKGROUND_RGB, axis=2) > 2
            out[m] = self.full_edges[m]
            return out
        for segment in self.segments:
            local = (frame - (segment['settled'] - 12.0)) / 12.0
            if local <= 0:
                continue
            p = float(smooth01(local))
            angle = segment['angle'] * (1.0-p)
            c, s = np.cos(angle), np.sin(angle)
            rot = np.array([[c,-s],[s,c]],np.float32)
            pts = (segment['points']-segment['center']) @ rot.T + segment['center']
            pts += segment['offset'] * (1.0-p)**1.35
            opacity = float(smooth01(local/.35))
            # Variation disappears as fragments lock into one continuous stroke;
            # otherwise the last assembly frame would visibly change exposure.
            final_shade = BACKGROUND_RGB+(np.array([140,139,149])-BACKGROUND_RGB)*self.edge_gain
            segment_shade = np.array(segment['shade'])*(1-p)+final_shade*p
            shade = tuple(int(BACKGROUND_RGB[k]+opacity*(segment_shade[k]-BACKGROUND_RGB[k])) for k in range(3))
            cv2.polylines(out,[np.rint(pts).astype(np.int32)],False,shade,1,cv2.LINE_AA)
        return out

    def _static_ui(self, target, frame):
        source = self.frames[min(max(int(frame),0),len(self.frames)-1)]
        mask = cv2.resize(self.static_ui_mask_native, (WIDTH,HEIGHT), interpolation=cv2.INTER_LINEAR).astype(np.float32)/255
        src = self._size(source)
        return np.uint8(np.clip(target*(1-mask[...,None])+src*mask[...,None],0,255))

    def overlay_hud(self, living_face_rgb, frame):
        """Preserve the reference fine HUD/text with no original face patches.

        Useful after the intro. Only tiny high-luminance glyphs in known HUD
        rectangles are lifted; source skin/hair pixels do not transfer.
        """
        target = self._size(living_face_rgb).astype(np.float32)
        source_index = min(max(int(frame),130),len(self.frames)-1)
        src = self.frames[source_index].astype(np.float32)
        h,w = src.shape[:2]
        roi = np.zeros((h,w),np.uint8)
        # Upper-left tech caption/progress rule, corner brackets, bottom text.
        for x0,y0,x1,y1 in [(26,25,204,62),(7,5,36,34),(718,5,751,36),
                            (7,430,36,467),(718,430,751,467),(27,445,110,464),
                            (265,437,500,455),(675,445,758,473)]:
            roi[y0:y1,x0:x1] = 1
        # High-pass isolates tiny text/lines instead of transferring its black
        # rectangle or any source hair beneath it.
        blur = cv2.GaussianBlur(src,(0,0),3)
        high = np.maximum(src-blur,0).mean(axis=2)
        lum = src.mean(axis=2)
        alpha = np.clip((high-6)/65,0,1) * np.clip((lum-45)/65,0,1) * roi
        alpha = cv2.resize(alpha,(WIDTH,HEIGHT),interpolation=cv2.INTER_LINEAR)
        glyph = self._size(np.uint8(np.clip(src,0,255))).astype(np.float32)
        return np.uint8(np.clip(target*(1-alpha[...,None])+glyph*alpha[...,None],0,255))

    def render(self, frame, living_face_rgb=None):
        frame = int(frame)
        if frame <= 32:
            source = self.frames[max(frame,0)].copy()
            x,y,w,h = self.avatar_rect_native
            source[y:y+h,x:x+w] = self.avatar
            return self._size(source)
        if self.exact_template:
            if frame <= 125:
                return self.source_frame(frame)
            if living_face_rgb is None:
                raise ValueError('Exact mode needs the retargeted living frame from frame126 onward.')
            return self._size(living_face_rgb)
        if frame <= 68:
            return self.source_frame(frame)
        if frame <= 119:
            out = self._settling_contours(frame).astype(np.float32)
            source = self.source_frame(frame).astype(np.float32)
            formed_front = (frame-76.0)/44.0
            # Direct original fragments still travelling on the right; replace
            # them only as the new character's line segments approach their sites.
            source_alpha = smooth01((self.xx-(formed_front+.025))/.20)
            result = out*(1-source_alpha[...,None])+source*source_alpha[...,None]
            return self._static_ui(np.uint8(np.clip(result,0,255)),frame)
        living = self.closed if living_face_rgb is None else self._size(living_face_rgb)
        if frame <= 131:
            edges = self._settling_contours(120).astype(np.float32)
            a,b,c = FLASH[frame]
            out = np.clip(a*edges+b*living.astype(np.float32)+np.array(c),0,255).astype(np.uint8)
            return self._static_ui(out,frame) if frame <= 125 else self.overlay_hud(out,frame)
        return self.overlay_hud(living,frame)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reference',required=True)
    parser.add_argument('--closed',required=True)
    parser.add_argument('--open',required=True)
    parser.add_argument('--output',required=True)
    parser.add_argument('--frames',default='0,32,33,39,45,60,75,80,85,90,95,100,105,110,115,120,122,123,124,125')
    parser.add_argument('--approximate-contours',action='store_true')
    args=parser.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    renderer=ReferenceIntro(args.reference,_rgb(args.closed),_rgb(args.open),exact_template=not args.approximate_contours)
    for frame in [int(v) for v in args.frames.split(',')]:
        rgb=renderer.render(frame)
        cv2.imwrite(str(out/f'frame-{frame:04d}.jpg'),cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR),[cv2.IMWRITE_JPEG_QUALITY,95])
    (out/'intro-measurements.json').write_text(json.dumps(renderer.reference_metadata,indent=2))
    print(json.dumps({'output':str(out),'mode':renderer.reference_metadata.get('mode','approximate'),'segments':len(getattr(renderer,'segments',[]))}))


if __name__=='__main__':
    main()
