#!/usr/bin/env python3
"""Compose every frame on the supplied reference's original timeline.

The reference supplies the motion, particle trajectories, flash and graphics.
The generated character supplies appearance, including the alternate irises.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
try:
    import cv2
except ImportError:
    sys.path.insert(0, str(ROOT.parent/'motion_work/python_packages'))
    import cv2
from reference_intro import ReferenceIntro

def load_module(path):
    spec = importlib.util.spec_from_file_location('reference_motion', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--motion-module', type=Path, default=ROOT/'scripts/reference_motion.py')
    p.add_argument('--output', type=Path, default=ROOT/'public/assets/final')
    p.add_argument('--frames', default='all')
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    module = load_module(args.motion_module)
    rig = module.ReferenceRetargeter(
        source_path=ROOT/'public/assets/reference/source.mp4',
        open_path=ROOT/'public/assets/character/reference_aligned_open.png',
        closed_path=ROOT/'public/assets/character/reference_aligned_closed.png',
        cache_directory=ROOT/'.cache/motion',
        boundaries_path=ROOT/'scripts/aperture_boundaries.json')
    opened = cv2.imread(str(ROOT/'public/assets/character/reference_aligned_open.png'))
    closed = cv2.imread(str(ROOT/'public/assets/character/reference_aligned_closed.png'))
    intro = ReferenceIntro(ROOT/'public/assets/reference/source.mp4',
                           cv2.cvtColor(closed, cv2.COLOR_BGR2RGB),
                           cv2.cvtColor(opened, cv2.COLOR_BGR2RGB),
                           exact_template=True)
    frames = range(298) if args.frames == 'all' else [int(x) for x in args.frames.split(',')]
    began = time.time()
    for f in frames:
        living = None
        if f >= 126:
            im = rig.render(f)
            im = cv2.resize(im, (1440, 900), interpolation=cv2.INTER_CUBIC)
            living = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
        rgb = intro.render(f, living)
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        ok = cv2.imwrite(str(args.output/f'frame-{f:04d}.png'), bgr,
                         [cv2.IMWRITE_PNG_COMPRESSION, 3])
        if not ok:
            raise RuntimeError(f'Could not write frame {f}')
        if f % 30 == 0:
            print(f'Composited frame {f}/298 | {time.time()-began:.1f}s', flush=True)
    report = {'output': str(args.output), 'count':len(list(args.output.glob('frame-*.png'))),
              'rendered_count_this_run':len(frames), 'fps':30,
              'source_crop':[177,20,758,473], 'source_first_frame':0,
              'source_last_frame':297, 'intro':intro.reference_metadata,
              'duration':298/30, 'elapsed_seconds':time.time()-began}
    (args.output/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

if __name__ == '__main__':
    main()
