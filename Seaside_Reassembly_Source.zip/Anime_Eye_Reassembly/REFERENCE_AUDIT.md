# Reference fidelity audit for v9

## Source boundary and frame identity

The source is a screen recording of a composed animation inside a window. The animation content is the rectangle `(x=177,y=20,width=758,height=473)` inside 1112×512 video. That content already has essentially the same 1.6 aspect ratio as the existing 1440×900 delivery. Changing the final aspect ratio is unnecessary; the important mismatch is internal artwork composition.

Frames 0–297 inclusive are the animation. Frame 298 at 9.933 seconds begins revealing editor chrome along the top and bottom; frame 299 clearly shows the editor menu. A clean animation delivery should therefore use 298 frames at 30fps, duration 9.933333 seconds, unless the user separately requests a longer ending.

The playback countdown entering at the lower left around frame 267 is external recording UI. It crosses the content border from outside and should not be copied. The internal caption, corner marks, SYNC RATIO display and watermark are part of the supplied animation design.

## Why v8 still did not match

| Component | Supplied reference | v8 difference |
|---|---|---|
| First frame | Complete welcome layout already visible | A fade-up/drawing animation was added |
| Avatar | Approx. 161×162 native square, centered near (379.5,226.5) | Wide thumbnail, only 234×146 at 1440×900; too small |
| Ring | Approx. 123px native radius, about 234px at delivery size | 147px delivery radius; much too small |
| Welcome title | Native y385–413; around 53px text height at delivery size | 31px text height and placed much too high |
| Shatter onset | Frame 32, 1.067s, entire avatar/ring/title breaking up | About 1.22s, mainly the thumbnail with separate fading UI |
| Particle cloud | Cloud already formed by frame42,1.4s; exact source trajectories available | Newly simulated outward explosion until around1.98s |
| Reassembly | Left-to-right line structure begins around76,2.533s, completes120,4.0s | Shorter contour phase, photographic color starts too early at3.38s |
| Photographic reveal | Abrupt white flash with peak frames123–124; image settles by130 | Smooth dark-to-photo opacity blend; no reference flash |
| Character framing | Nose bridge to right, large near eye low left, far eye upper right, dense bangs dominating upper half | Face tilted opposite direction, eyes smaller in composition, more pale face visible |
| Visual exposure | Predominantly black/lilac with luminous side cheek and saturated red irises | Bright beige face and cool blue irises; much higher overall brightness |
| Eyelids | Thick, sweeping upper lash fans visibly rotate as lids lift | Fine lashes, narrower eyelid scale change; silhouette and weighting differ |
| On-screen details | Constant corners plus sync indicator and true caption | Absent |
| Ending | Animation ends before recorder/editor UI, last clean frame297 | Extra2.07s prolonged open face to12s |

Eye timing alone was not the principal remaining global mismatch. The reference already establishes tension through layout, darker lighting, long line reconstruction and a flash; these differences change the perceived beat even if an opening curve is close.

## Frame-accurate global targets

- Welcome hold:0–31.
- First break:32. Obvious shards:33–40. Cloud by42.
- Particle-to-line reconstruction:approximately76–120.
- Flash starts122; peaks123–124; decays125–129; photographic state established130.
- Closed pose hold through approximately222, with slight release before first iris.
- Narrow iris visible around238–240.
- Main eye lift240–250.
- Settled gaze around276.
- Final clean animation frame297.

The measured source mean-luminance values for frames120–130 are respectively 17.37,18.89,45.06,193.16,194.64,180.92,125.03,98.61,74.11,61.93,60.60. These values include character lighting and should guide flash shape, not force a differently colored character to identical absolute luminance.

## Direct-source reconstruction recommendation

Reuse the source welcome/ring/text/interface pixels and source particle cloud wherever those pixels do not represent the old character. Replace only the square avatar for0–31. Later shard blocks are almost monochrome and can use source trajectories with new avatar texture if necessary. For contour reconstruction, keep the source cloud beyond the observed reveal boundary while mapping the line structure to the replacement character. Do not substitute a smooth fade for the flash.

The character should be created in the reference pose and crop from the beginning. Retargeting a face with the opposite tilt and smaller eyes cannot produce a1:1 effect through changing timing alone. Preserve eyelash silhouette and eyelid geometry as motion constraints even though facial identity and iris colors differ.

## Deliverables from this analysis

- `reference-crop.json`: exact crop, frame boundaries, mappings, phases and HUD ROIs.
- `reference_content_clean.mp4`: same-source clean animation crop, 298frames.
- `reference_clean_frames/0000.png` through`0297.png`: decoded native content pixels.
- `reference_native_0180.png`, `reference_native_0286.png`: closed/open stills.
- `reference_1440x900_0180.png`, `reference_1440x900_0286.png`: delivery-size design references.
- `reference_hud.py`: sparse per-frame UI glyph layer; no source portrait rectangles.
- `review_round.py`: CLI and importable `review_three_column` API, same-time source/v8/candidate images.
- `v8_baseline_review/`: completed baseline round using the actual previous output.

## Review limitations

No eye-identity-independent pixel metric can certify that a new character is perceptually identical to the reference effect. Use exact frame/pixel checks for unchanged carrier layers, and inspect matched contact sheets for geometry and motion. The UI extraction preserves per-frame observed glyph coverage; it estimates antialias transparency so that no old skin/hair patch is copied. Watermark dark panel is rebuilt over the new character. This is a compositing approximation, explicitly separated from the exact source carrier frames.
