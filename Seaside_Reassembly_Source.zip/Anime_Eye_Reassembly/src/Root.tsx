import React from 'react';
import {Composition} from 'remotion';
import {Portrait} from './Portrait';

export const Root = () => <Composition id="EyeCloseup" component={Portrait}
  durationInFrames={298} fps={30} width={1440} height={900} />;
