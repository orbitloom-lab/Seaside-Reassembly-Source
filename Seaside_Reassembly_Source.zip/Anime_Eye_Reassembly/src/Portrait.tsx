import React from 'react';
import {AbsoluteFill, Audio, Img, staticFile, useCurrentFrame} from 'remotion';

/** Source-driven animation: one finished raster per reference frame. */
export const Portrait = () => {
  const frame = Math.min(297, Math.max(0, useCurrentFrame()));
  return <AbsoluteFill style={{background: '#08070d'}}>
    <Img src={staticFile(`assets/final/frame-${String(frame).padStart(4, '0')}.png`)}
      style={{width: '100%', height: '100%', objectFit: 'fill'}} />
    <Audio src={staticFile('assets/reference-audio.m4a')} />
  </AbsoluteFill>;
};
