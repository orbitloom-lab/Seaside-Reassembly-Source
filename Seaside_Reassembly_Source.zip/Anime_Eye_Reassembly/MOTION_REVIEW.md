# Reference motion retarget v9

## Production API

`source_authoritative_retarget.ReferenceRetargeter(source_path=None, open_path=None, closed_path=None, cache_directory=None, boundaries_path=None)`.

`render(frame, debug=False)` returns native758×473 BGRuint8 for original source frames126–297 inclusive. With debug=True, `_debug` contains source, `iris_mask`, per-eye movement and visible material area. All motion and geometric luminance boundaries come from the actual corresponding source frame. This is appearance retargeting on the reference animation, not a newly interpolated eyelid rig.

Required portable files: source_authoritative_retarget.py, build_motion_maps.py, aperture_boundaries.json; plus source reference video and generated open/closed character assets. Missing motion cache regenerates from source with build_motion_maps.build_fields(source_path, cache_directory). Do not include168MB reconstructible cache in source ZIP.

## Fixed problems through rendered rounds

1. Unrestricted full-image optical-flow target remapping rejected: folded featureless hair and duplicated closed lashes below eyes after opening.
2. Source-authoritative structure accepted, but material coordinates initially wrong and broadUI restoration made rectangle borders. Corrected with per-eye affine registration and pixel-level brightUI restoration.
3. Full-reference iris movement is distinct from lid motion: current→open284 approximate iris translation at8.0s is(-23,-48)left,(-17,-46)right. Iris texture must translate beneath lid masks; never compress to aperture height. Corrected early clipping and source-value mismatch.
4. Anatomical lower-lid masks manually annotated from actual frames234/235/240/246/260/284. Source black eyelashes determine upper occlusion. This removes blue lower-skin leakage and original right red crescent.
5. Dense mask verification of172 frames checks source-derived visible material. Both independent reviewers supplied manual skin/iris points.17skin points remain0,10iris points remain1. Source left remainsfullycoveredthrough234, firsttrueiris235. Right hasdarkslit208–210 andclearwedge211; observation guardonlythrough207 prevents earlyflash/skin misclassification.

## Preserved content and practical interpretation

The actual source body/head/hair/eyelid geometry, frame holds, expression progression, and overlay timing remain authoritative. Generated keyframes provide complexion reference, cool hair appearance, and replacement blue-violet/gold iris material; they are not warped wholesale into final frames. Original white speculars, black pupil/eyelash silhouettes and fine geometry retain source positions exactly. Music is owned by parent assembly and must remain at offset0.

The recording countdown text at croppedlowerleft afterframe267 is inpainted locally. DesktopandexternalrecordingUI are handled by parent crop/assembly. Source-design HUD/caption remains retained.
